import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.*;
import java.net.*;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws IOException, URISyntaxException, InterruptedException {
        System.setProperty("java.util.Arrays.useLegacyMergeSort", "true");

//        Path path = Paths.get("/Users/jijo/Documents/page2.html");
//
//        BufferedReader reader = Files.newBufferedReader(path);
//        reader.lines().forEach(line->{
//           // System.out.println(line);
//        });

        //openUrl();
        String filePath = sendPostWithFormData("123271");
        File input = new File(filePath);
        Document doc = Jsoup.parse(input, "UTF-8");

        Element searchList = doc.select(".search-listitem.mb-2").first();
        Elements newsHeadlines = searchList.select(".bg-white.border.mt-2.px-1.py-3.d-flex.flex-wrap");

        for (Element title : newsHeadlines) {

            Element itemlist = title.select(".auction-Itemlist-Title").first();
            Element link = itemlist.select("a[href]").first();
            link.attr("href", "https://auction.primeauctions.com" + link.attr("href"));
            try {
                int price = ((Float) Float.parseFloat(Objects.requireNonNull(link).text().split("\\$")[1].replaceAll(",",""))).intValue();
                title.attr("data-index", price + "");
                //System.out.println(price);
            } catch (Exception e) {
                System.out.println(e+link.text());
            }
            //System.out.println(title);

        }

        newsHeadlines.sort(new Comparator<Element>() {
            @Override
            public int compare(Element e1, Element e2) {
                String s1 = e1.attr("data-index");
                String s2 = e2.attr("data-index");
                try {


                    int price1 = 0, price2 = 0;
                    if (isNotEmptyString(s1) && isNotEmptyString(s2)) {
                        try {
                            price1 = Integer.parseInt(s1);
                            price2 = Integer.parseInt(s2);
                        } catch (Exception e) {
                            System.out.println("s1=" + s1 + ",s2=" + s2);
                        }
                    }

                    return price2 - price1;
                } catch (Exception e) {
                    System.out.println("s1=" + s1 + ",s2=" + s2);
                    return 0;
                }


            }
        });
        searchList.html(newsHeadlines.html().replaceAll("height=\"125\"", "height=\"225\"").replaceAll("h6", "h4"));
        Path output = Path.of("/Users/jijo/Documents/page2output.html");
        Files.writeString(output, doc.outerHtml());

    }

    private static String readFromInputStream(InputStream inputStream)
            throws IOException {
        StringBuilder resultStringBuilder = new StringBuilder();
        try (BufferedReader br
                     = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            while ((line = br.readLine()) != null) {
                resultStringBuilder.append(line).append("\n");
            }
        }
        return resultStringBuilder.toString();
    }

    private static void openUrl() throws IOException {
        URL urlObject = new URL("https://auction.primeauctions.com/Public/AdvancedSearch/GetAdvancedSearchResults?pageNumber=1&pagesize=10000&filter=&keyWordSearch=&keyWordOrder=AnyOrder&auctionStatus=Current&priceStart=NaN&priceEnd=NaN&countryId=&stateid=&auctionType=&itemCategories=&sortBy=enddate_desc&_=1714768841449");
//        URL urlObject = new URL("\n" +
//                "https://auction.primeauctions.com/Public/GlobalSearch/GetGlobalSearchResults?pageNumber=1&pagesize=100&filter=Current&sortBy=enddate_asc&search=9&_=1717021927483");

        URLConnection urlConnection = urlObject.openConnection();
        urlConnection.addRequestProperty("X-Requested-With", "XMLHttpRequest");
        InputStream inputStream = urlConnection.getInputStream();
        String data = readFromInputStream(inputStream);
        Path path = Paths.get("/Users/jijo/Documents/page2.html");
        byte[] strToBytes = data.getBytes();

        Files.write(path, strToBytes);
    }

    private static void openPostUrl() throws IOException {
        URL urlObject = new URL("https://auction.primeauctions.com/Public/Auction/GetAuctionItems");
//        URL urlObject = new URL("\n" +
//                "https://auction.primeauctions.com/Public/GlobalSearch/GetGlobalSearchResults?pageNumber=1&pagesize=100&filter=Current&sortBy=enddate_asc&search=9&_=1717021927483");

        URLConnection urlConnection = urlObject.openConnection();
        urlConnection.addRequestProperty("X-Requested-With", "XMLHttpRequest");
        InputStream inputStream = urlConnection.getInputStream();
        String data = readFromInputStream(inputStream);
        Path path = Paths.get("/Users/jijo/Documents/page2.html");
        byte[] strToBytes = data.getBytes();

        Files.write(path, strToBytes);
    }

    public static String  sendPostWithFormData(String auctionId) throws IOException, InterruptedException {
        String serviceUrl = "https://auction.primeauctions.com/Public/Auction/GetAuctionItems";
        HttpClient client = HttpClient.newHttpClient();
        String filePath = "/Users/jijo/Documents/page3.html";
        Map<String, String> formData = new HashMap<>();
        formData.put("AuctionId", auctionId);
        formData.put("pageNumber", "1");
        formData.put("itemsPerPage", "100");
        formData.put("viewType", "3");
        formData.put("Categoryfilter", "");
        formData.put("ShowFilter", "all");
        formData.put("SortBy", "currentbid_desc");
        formData.put("SearchFilter", "");
        formData.put("pageSize", "100");
        formData.put("Filter", "Current");
        formData.put("oldPageNumber", "");

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(serviceUrl))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(getFormDataAsString(formData)))
                .build();

        HttpResponse<String> response = client
                .send(request, HttpResponse.BodyHandlers.ofString());

        Path path = Paths.get("/Users/jijo/Documents/page3.html");
        byte[] strToBytes = response.body().getBytes();

        Files.write(path, strToBytes);
        return filePath;
    }

    private static String getFormDataAsString(Map<String, String> formData) {
        StringBuilder formBodyBuilder = new StringBuilder();
        for (Map.Entry<String, String> singleEntry : formData.entrySet()) {
            if (formBodyBuilder.length() > 0) {
                formBodyBuilder.append("&");
            }
            formBodyBuilder.append(URLEncoder.encode(singleEntry.getKey(), StandardCharsets.UTF_8));
            formBodyBuilder.append("=");
            formBodyBuilder.append(URLEncoder.encode(singleEntry.getValue(), StandardCharsets.UTF_8));
        }
        return formBodyBuilder.toString();
    }


    static boolean isNotEmptyString(String string) {
        return string != null && !string.isEmpty();
    }
}

