import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.*;
import java.net.*;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;


public class PrimeDaily {

    static String searchCriteria="";
    static String path="/Users/jijo/Documents/page3output.html";
    static String auctionNumber="123629";
    static int numberOfPages=42;

    public static void main(String[] args) throws IOException, URISyntaxException, InterruptedException {
        System.setProperty("java.util.Arrays.useLegacyMergeSort", "true");

//        Path path = Paths.get("/Users/jijo/Documents/page2.html");
//
//        BufferedReader reader = Files.newBufferedReader(path);
//        reader.lines().forEach(line->{
//           // System.out.println(line);
//        });

        //openUrl();
        try {
            String filePath = sendPostWithFormData(auctionNumber, numberOfPages);
            File input = new File(filePath);
            Document doc = Jsoup.parse(input, "UTF-8");

            Elements pics = doc.select(".col-lg-4.col-md-3.px-2");
            Elements outputElements = new Elements();
            for (Element pic : pics) {
                Element sibling = pic.nextElementSibling();
                Element itemlist = sibling.select(".auction-Itemlist-Title").first();
                Element link = itemlist.select("a[href]").first();
                link.attr("href", "https://auction.primeauctions.com" + link.attr("href"));
                int price = 0;
                try {
                    price = ((Float) Float.parseFloat(Objects.requireNonNull(link).text().split("\\$")[1].replaceAll(",", ""))).intValue();

                } catch (Exception e) {
                    //System.out.println(e + link.text());
                }
                Element newElm = new Element("div");
                newElm.attr("data-index", price + "");
                newElm.appendChild(pic);
                newElm.appendChild(sibling);
                System.out.println(price);
                outputElements.add(newElm);
             }

            outputElements.sort(new Comparator<Element>() {
                @Override
                public int compare(Element e1, Element e2) {
                    String s1 = e1.attr("data-index");
                    String s2 = e2.attr("data-index");
                    try {
                        int price1 = 0, price2 = 0;
                        if (isNotEmptyString(s1) && isNotEmptyString(s2)) {
                            try {
                                price1 = Integer.parseInt(s1);
                                price2 = Integer.parseInt(s2);
                            } catch (Exception e) {
                                System.out.println("s1=" + s1 + ",s2=" + s2);
                            }
                        }
                     return price2 - price1;
                    } catch (Exception e) {
                        System.out.println("s1=" + s1 + ",s2=" + s2);
                        return 0;
                    }
                }
            });
            //searchList.html(newsHeadlines.html().replaceAll("height=\"125\"", "height=\"225\"").replaceAll("h6", "h4"));
            Path output = Path.of(path);
            Files.writeString(output, outputElements.html());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String readFromInputStream(InputStream inputStream) throws IOException {
        StringBuilder resultStringBuilder = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            while ((line = br.readLine()) != null) {
                resultStringBuilder.append(line).append("\n");
            }
        }
        return resultStringBuilder.toString();
    }

    private static void openUrl() throws IOException {
        URL urlObject = new URL("https://auction.primeauctions.com/Public/AdvancedSearch/GetAdvancedSearchResults?pageNumber=1&pagesize=10000&filter=&keyWordSearch=&keyWordOrder=AnyOrder&auctionStatus=Current&priceStart=NaN&priceEnd=NaN&countryId=&stateid=&auctionType=&itemCategories=&sortBy=enddate_desc&_=1714768841449");
//        URL urlObject = new URL("\n" +
//                "https://auction.primeauctions.com/Public/GlobalSearch/GetGlobalSearchResults?pageNumber=1&pagesize=100&filter=Current&sortBy=enddate_asc&search=9&_=1717021927483");

        URLConnection urlConnection = urlObject.openConnection();
        urlConnection.addRequestProperty("X-Requested-With", "XMLHttpRequest");
        InputStream inputStream = urlConnection.getInputStream();
        String data = readFromInputStream(inputStream);
        Path path = Paths.get("/Users/jijo/Documents/page2.html");
        byte[] strToBytes = data.getBytes();

        Files.write(path, strToBytes);
    }

    private static void openPostUrl() throws IOException {
        URL urlObject = new URL("https://auction.primeauctions.com/Public/Auction/GetAuctionItems");
//        URL urlObject = new URL("\n" +
//                "https://auction.primeauctions.com/Public/GlobalSearch/GetGlobalSearchResults?pageNumber=1&pagesize=100&filter=Current&sortBy=enddate_asc&search=9&_=1717021927483");

        URLConnection urlConnection = urlObject.openConnection();
        urlConnection.addRequestProperty("X-Requested-With", "XMLHttpRequest");
        InputStream inputStream = urlConnection.getInputStream();
        String data = readFromInputStream(inputStream);
        Path path = Paths.get("/Users/jijo/Documents/page2.html");
        byte[] strToBytes = data.getBytes();

        Files.write(path, strToBytes);
    }

    public static String sendPostWithFormData(String auctionId, int numberOfPages) throws IOException, InterruptedException {
        String serviceUrl = "https://auction.primeauctions.com/Public/Auction/GetAuctionItems";
        HttpClient client = HttpClient.newHttpClient();
        String filePath = "/Users/jijo/Documents/page3.html";
        Map<String, String> formData = new HashMap<>();
        formData.put("AuctionId", auctionId);
        formData.put("itemsPerPage", "100");
        formData.put("viewType", "3");
        formData.put("Categoryfilter", "");
        formData.put("ShowFilter", "openitems");
        formData.put("SortBy", "currentbid_desc");
        formData.put("SearchFilter", searchCriteria);
        formData.put("pageSize", "100");
        formData.put("Filter", "Current");
        formData.put("oldPageNumber", "");
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        for (int pageNumber = 1; pageNumber <= numberOfPages; pageNumber++) {
            formData.put("pageNumber", pageNumber + "");

            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(serviceUrl))
                    .header("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                    .header("X-Requested-With", "XMLHttpRequest")
                    .header("__RequestVerificationToken", "8UxGdrHiuiWfpscAjM0n8WDQ6GR4g8Algugk5PBCaA0sDNB58WX1PIElvR3OximVioYHDg2IkGue1TtX-273gYRvAHjW63p203qQS8san5841uCGFO4fMTIz7nC-y9GI0")
                    .POST(HttpRequest.BodyPublishers.ofString(getFormDataAsString(formData))).build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            outputStream.write(response.body().getBytes());
        }
        Path path = Paths.get(filePath);
        Files.write(path, outputStream.toByteArray());
        return filePath;
    }

    private static String getFormDataAsString(Map<String, String> formData) {
        StringBuilder formBodyBuilder = new StringBuilder();
        for (Map.Entry<String, String> singleEntry : formData.entrySet()) {
            if (formBodyBuilder.length() > 0) {
                formBodyBuilder.append("&");
            }
            formBodyBuilder.append(URLEncoder.encode(singleEntry.getKey(), StandardCharsets.UTF_8));
            formBodyBuilder.append("=");
            formBodyBuilder.append(URLEncoder.encode(singleEntry.getValue(), StandardCharsets.UTF_8));
        }
        return formBodyBuilder.toString();
    }


    static boolean isNotEmptyString(String string) {
        return string != null && !string.isEmpty();
    }
}

